export let urls = JSON.parse(localStorage.getItem('urls')) || []

export function clearUrls(){
    urls = []
    saveToStorage()
}

function saveToStorage(){
    localStorage.setItem('urls', JSON.stringify(urls))
}

export function addUrl(value){
    urls.push(value)
    saveToStorage()
}