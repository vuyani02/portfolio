import { urls, clearUrls, addUrl } from "./data.js"

let html = ''
const saveInputEl = document.querySelector('.save-input')
const inputEl = document.querySelector('.input')
const deleteEl = document.querySelector('.delete')
const saveTabEl = document.querySelector('.save-tab')

updatePage()

saveInputEl.addEventListener('click', () => {
    if(inputEl.value){
    addUrl(inputEl.value)
    inputEl.value = ''
    updatePage()
    }
})

deleteEl.addEventListener('click', () => {
    clearUrls()
    updatePage()
})

saveTabEl.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        let currentTab = tabs[0];
        if (currentTab) {
            addUrl(currentTab.url)
            updatePage()
        }
    });
})

function updatePage(){
    urls.forEach(link => {
    html += `<li><a href="${link}" target="_blank">${link}</a></li>`
    });

    document.querySelector('.ul').innerHTML = html
    html = ''
}